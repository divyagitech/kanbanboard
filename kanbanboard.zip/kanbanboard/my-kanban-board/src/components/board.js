import React, { useState, useEffect } from 'react';
import TicketCard from './card';
import { fetchData } from '../utils/api';
import '../styles.css';

const KanbanBoard = () => {
  const [tickets, setTickets] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [displayState, setDisplayState] = useState('status');

  useEffect(() => {
    fetchData()
      .then((data) => {
        setTickets(data);
        setIsLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
        setIsLoading(false);
      });
  }, []);

  const groupTicketsByStatus = () => {
    const groupedTickets = {
      Backlog: [],
      Todo: [],
      'In Progress': [],
      Done: [],
      Cancelled: [],
    };

    tickets.forEach((ticket) => {
      if (!groupedTickets[ticket.status]) {
        groupedTickets[ticket.status] = [];
      }
      groupedTickets[ticket.status].push(ticket);
    });

    return groupedTickets;
  };

  const groupTicketsByPriority = () => {
    const groupedTickets = {
      'No Priority': [],
      Low: [],
      Medium: [],
      High: [],
      Urgent: [],
    };

    tickets.forEach((ticket) => {
      if (ticket.priority === 0) {
        groupedTickets['No Priority'].push(ticket);
      } else if (ticket.priority === 1) {
        groupedTickets['Low'].push(ticket);
      } else if (ticket.priority === 2) {
        groupedTickets['Medium'].push(ticket);
      } else if (ticket.priority === 3) {
        groupedTickets['High'].push(ticket);
      } else if (ticket.priority === 4) {
        groupedTickets['Urgent'].push(ticket);
      }
    });

    return groupedTickets;
  };

  const sortedTicketsByStatus = groupTicketsByStatus();
  const sortedTicketsByPriority = groupTicketsByPriority();

  const handleDisplayStateChange = (state) => {
    setDisplayState(state);
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (tickets.length === 0) {
    return <div>No tickets available</div>;
  }

  const countTickets = (status) => {
    return sortedTicketsByStatus[status]?.length || 0;
  };
  const countTicket = (priority) => {
    return sortedTicketsByPriority[priority]?.length || 0;
  };

  return (
    <div className="kanban-board">
      <div className="display-state-options">
        <label>
          Display:
          <select
            value={displayState}
            onChange={(e) => handleDisplayStateChange(e.target.value)}
          >
            <option value="status">Status</option>
            <option value="priority">Priority</option>
          </select>
        </label>
      </div>

      {displayState === 'status' ? (
        <div className="status-columns-container">
          <div className="status-column">
            <b>Backlog ({countTickets('Backlog')})</b>
            <div className="ticket-cards">
              {sortedTicketsByStatus['Backlog'].map((ticket) => (
                <TicketCard key={ticket.id} ticket={ticket} />
              ))}
            </div>
          </div>
          <div className="status-column">
            <b>Todo ({countTickets('Todo')})</b>
            <div className="ticket-cards">
              {sortedTicketsByStatus['Todo'].map((ticket) => (
                <TicketCard key={ticket.id} ticket={ticket} />
              ))}
            </div>
          </div>
          <div className="status-column">
            <b>In Progress ({countTickets('In Progress')})</b>
            <div className="ticket-cards">
              {sortedTicketsByStatus['In Progress'].map((ticket) => (
                <TicketCard key={ticket.id} ticket={ticket} />
              ))}
            </div>
          </div>
          <div className="status-column">
            <b>Done ({countTickets('Done')})</b>
            <div className="ticket-cards">
              {sortedTicketsByStatus['Done'].map((ticket) => (
                <TicketCard key={ticket.id} ticket={ticket} />
              ))}
            </div>
          </div>
          <div className="status-column">
            <b>Cancelled ({countTickets('Cancelled')})</b>
            <div className="ticket-cards">
              {sortedTicketsByStatus['Cancelled'].map((ticket) => (
                <TicketCard key={ticket.id} ticket={ticket} />
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="priority-columns-container">
          <div className="priority-column">
            <b>No Priority ({countTicket('No Priority')})</b>
            <div className="ticket-cards">
              {sortedTicketsByPriority['No Priority'].map((ticket) => (
                <TicketCard key={ticket.id} ticket={ticket} />
              ))}
            </div>
          </div>
          <div className="priority-column">
            <b>Urgent ({countTicket('Urgent')})</b>
            <div className="ticket-cards">
              {sortedTicketsByPriority['Urgent'].map((ticket) => (
                <TicketCard key={ticket.id} ticket={ticket} />
              ))}
            </div>
          </div>
          <div className="priority-column">
            <b>High ({countTicket('High')})</b>
            <div className="ticket-cards">
              {sortedTicketsByPriority['High'].map((ticket) => (
                <TicketCard key={ticket.id} ticket={ticket} />
              ))}
            </div>
          </div>
          <div className="priority-column">
            <b>Medium ({countTicket('Medium')})</b>
            <div className="ticket-cards">
              {sortedTicketsByPriority['Medium'].map((ticket) => (
                <TicketCard key={ticket.id} ticket={ticket} />
              ))}
            </div>
          </div>
          <div className="priority-column">
            <b>Low ({countTicket('Low')})</b>
            <div className="ticket-cards">
              {sortedTicketsByPriority['Low'].map((ticket) => (
                <TicketCard key={ticket.id} ticket={ticket} />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default KanbanBoard;
