import React from 'react';
import '../styles.css';

const TicketCard = ({ ticket }) => {
  const isFeatureRequest = ticket.tag.includes('Feature Request');
  return (
    <div className="ticket-card">
      <h3>{ticket.id}</h3>
      <p>
        <b>{ticket.title}</b>
      </p>
      <p>
        {isFeatureRequest && <span className="tag-symbol">&#x2B50;</span>}
        {ticket.tag}
      </p>
    </div>
  );
};

export default TicketCard;
