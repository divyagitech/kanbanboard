import React from 'react';
import './App.css';
import KanbanBoard from './components/board';

function App() {
  return (
    <div className="App">
      <main>
        <KanbanBoard />
      </main>
    </div>
  );
}

export default App;
